# Code of Conduct

Be accurate, civil, attribution-aware, and evidence-oriented. Do not use the project to misrepresent certification, impersonate an official DIKWP registry, or harass competitors.
