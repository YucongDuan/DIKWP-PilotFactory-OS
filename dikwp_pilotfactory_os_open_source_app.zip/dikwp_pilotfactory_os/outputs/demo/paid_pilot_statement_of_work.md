# DIKWP Paid Pilot Statement of Work Draft

Client candidate: Huaxin Manufacturing Group
Portfolio route: sell_paid_pilot_first

## Scope
This draft scopes a human-reviewed DIKWP pilot. It does not grant official certification or production approval.

## Recommended pilot candidates
- uc-001: paid_pilot_candidate / tier=enterprise_pilot / modules=AICAP-Gateway, AgentTrace, IntentGuard, ProofLedger
- uc-002: qualified_discovery_candidate / tier=starter_pilot / modules=AnswerGraph, ProofLedger
- uc-003: community_or_content_lead / tier=free_community_path / modules=ProofLedger, SemanticEnergy

## Deliverables
1. DIKWP pilot intake and evidence ledger.
2. Use-case-specific TrustOS module routing.
3. Risk, governance, and data readiness assessment.
4. Official service trigger map.
5. Pilot acceptance criteria and next-step commercial route.

## Exclusions
No legal certification, no production deployment, no live hardware control, no investment/medical/legal advice, and no official registry signature without separate authorized review.