# Official Service Boundary

Open-source reports are not official DIKWP certification. Official registry, badge, and signed reports require authorized human review.
