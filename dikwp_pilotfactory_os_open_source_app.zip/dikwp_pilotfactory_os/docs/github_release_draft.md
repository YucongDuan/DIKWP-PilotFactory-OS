# GitHub Release Draft

DIKWP PilotFactory OS v0.1.0 is now available.

This release helps teams convert enterprise AI ideas into DIKWP-aligned pilot opportunities, SOW drafts, pricing tiers, procurement checklists, and official service triggers.
