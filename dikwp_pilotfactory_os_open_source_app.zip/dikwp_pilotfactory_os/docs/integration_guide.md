# Integration Guide

PilotFactory OS can integrate conceptually with:
- TrustPassport OS for registry and badges.
- OriginMoat OS for open-core strategy.
- EcosystemRouter OS for partner routing.
- AICAP-Gateway OS for hardware-adjacent pilots.
- ProofLedger, IntentGuard, AgentTrace, MemoryLedger, SemanticEnergy for TrustOS modules.
