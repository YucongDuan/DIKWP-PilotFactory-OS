# Strategic Moat Design

Open-source code is copyable. Economic value should be captured through official registry, certification, signed pilot reports, partner onboarding, expert-reviewed adapter packs, and enterprise support.

PilotFactory OS is a lead-to-pilot routing layer. It should remain open enough to create adoption, but not include private issuer keys, official scoring authority, or client-specific playbooks.
