# Open Source Launch Plan

1. Publish repository with README, NOTICE, CITATION.cff, demo outputs, and clear boundary.
2. Pin it as the official DIKWP pilot conversion tool.
3. Release a public demo: manufacturing AI audit pilot.
4. Invite partners to submit pilot manifests.
5. Convert high-score manifests into paid discovery calls.
6. Offer official Pilot Report Review and TrustPassport registration.
