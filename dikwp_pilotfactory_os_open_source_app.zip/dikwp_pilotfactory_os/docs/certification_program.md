# Certification Program

Recommended tiers:
- DIKWP Pilot User
- DIKWP Pilot Analyst
- DIKWP Pilot Facilitator
- DIKWP Enterprise Pilot Reviewer
- DIKWP Certified Deployment Partner

Certification should require human review and cannot be issued automatically by this offline core.
