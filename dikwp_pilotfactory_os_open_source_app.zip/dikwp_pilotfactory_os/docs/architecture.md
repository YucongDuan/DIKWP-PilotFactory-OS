# Architecture

Input portfolio -> Use case scoring -> DIKWP pilot ledger -> TrustOS module route -> official service triggers -> paid pilot SOW -> procurement checklist.

Core modules:
- Evaluator
- DIKWP ledger compiler
- Report generator
- Static boundary audit

Official layers not included in the offline core:
- registry signing
- certified report issuance
- expert-reviewed industry adapters
- enterprise deployment playbooks
