# Roadmap

- v0.2: Add more industry templates.
- v0.3: Connect TrustPassport registry export.
- v0.4: Add partner scorecards.
- v0.5: Add enterprise CRM export.
- v1.0: Official DIKWP PilotFactory with human-reviewed pilot report workflow.
