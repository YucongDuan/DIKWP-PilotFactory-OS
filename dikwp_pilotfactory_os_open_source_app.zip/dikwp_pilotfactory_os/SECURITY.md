# Security Policy

This offline core is designed to avoid network calls, subprocess execution, dynamic code execution, hidden telemetry, and host mutation. Report security issues privately to the project maintainers.
