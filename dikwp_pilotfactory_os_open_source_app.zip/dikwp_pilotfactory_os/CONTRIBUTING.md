# Contributing

Contributions are welcome for the offline core, sample schemas, tests, and documentation. Do not submit code that adds hidden telemetry, network calls, subprocess execution, credential collection, live hardware control, or proprietary official registry issuance.
