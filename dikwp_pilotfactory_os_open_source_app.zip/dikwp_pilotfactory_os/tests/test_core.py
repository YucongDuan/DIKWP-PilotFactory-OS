import json, pathlib
from dikwp_pilotfactory.evaluator import analyze_portfolio, score_use_case
from dikwp_pilotfactory.static_audit import audit_path

BASE = pathlib.Path(__file__).resolve().parents[1]

def test_analyze_portfolio():
    data = json.loads((BASE / "examples/sample_enterprise_portfolio.json").read_text(encoding="utf-8"))
    policy = json.loads((BASE / "configs/default_policy.json").read_text(encoding="utf-8"))
    report = analyze_portfolio(data, policy)
    assert report["use_case_count"] == 3
    assert report["portfolio_route"] in {"sell_paid_pilot_first", "sell_discovery_assessment_first", "community_content_and_registry_nurture"}
    assert any(d["pricing_tier"] == "enterprise_pilot" for d in report["decisions"])

def test_score_use_case_modules():
    uc = {"use_case_id":"x", "name":"hardware PLC agent", "description":"agent controls hardware gateway", "pain_level":5, "budget_signal":5, "executive_sponsor": True}
    d = score_use_case(uc, {})
    assert "AICAP-Gateway" in d["recommended_modules"]


def test_static_audit_passes():
    result = audit_path(str(BASE / "src"))
    assert result["pass"] is True
