def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))

def slug(text: str) -> str:
    return ''.join(c.lower() if c.isalnum() else '-' for c in text).strip('-')
