import argparse, json, os
from .evaluator import analyze_portfolio
from .reports import write_outputs
from .static_audit import write_audit

def load_json(path):
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)

def main(argv=None):
    parser = argparse.ArgumentParser(prog="pilotfactory")
    sub = parser.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("analyze")
    a.add_argument("input")
    a.add_argument("--policy", default="configs/default_policy.json")
    a.add_argument("--out", default="outputs/demo")
    s = sub.add_parser("static-audit")
    s.add_argument("root")
    s.add_argument("--out", default="outputs/demo/static_boundary_audit_report.json")
    args = parser.parse_args(argv)
    if args.cmd == "analyze":
        data = load_json(args.input)
        policy = load_json(args.policy)
        report = analyze_portfolio(data, policy)
        write_outputs(args.out, data, report)
        print(json.dumps({"portfolio_route": report["portfolio_route"], "use_case_count": report["use_case_count"]}, ensure_ascii=False))
    elif args.cmd == "static-audit":
        os.makedirs(os.path.dirname(args.out), exist_ok=True)
        result = write_audit(args.root, args.out)
        print(json.dumps(result, ensure_ascii=False))

if __name__ == "__main__":
    main()
