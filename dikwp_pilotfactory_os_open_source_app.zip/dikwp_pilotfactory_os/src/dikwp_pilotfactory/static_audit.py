import ast, os, json

FORBIDDEN_IMPORTS = {"socket", "requests", "urllib", "httpx", "subprocess", "paramiko", "ftplib"}
FORBIDDEN_CALLS = {"eval", "exec", "compile", "open"}  # open is allowed in CLI/report modules; handled as warning exemption below.
EXEMPT_OPEN_FILES = {"cli.py", "reports.py", "static_audit.py"}

def audit_path(root: str):
    findings = []
    for dirpath, _, filenames in os.walk(root):
        for name in filenames:
            if not name.endswith('.py'):
                continue
            path = os.path.join(dirpath, name)
            try:
                tree = ast.parse(open(path, 'r', encoding='utf-8').read())
            except Exception as e:
                findings.append({"file": path, "type": "parse_error", "detail": str(e)})
                continue
            for node in ast.walk(tree):
                if isinstance(node, (ast.Import, ast.ImportFrom)):
                    mods = []
                    if isinstance(node, ast.Import):
                        mods = [a.name.split('.')[0] for a in node.names]
                    else:
                        mods = [(node.module or '').split('.')[0]]
                    for mod in mods:
                        if mod in FORBIDDEN_IMPORTS:
                            findings.append({"file": path, "type": "forbidden_import", "detail": mod})
                if isinstance(node, ast.Call):
                    func = getattr(node.func, 'id', None) or getattr(getattr(node.func, 'attr', None), 'id', None)
                    if isinstance(node.func, ast.Name):
                        func = node.func.id
                    if func in {"eval", "exec", "compile"}:
                        findings.append({"file": path, "type": "forbidden_call", "detail": func})
                    if func == "open" and name not in EXEMPT_OPEN_FILES:
                        findings.append({"file": path, "type": "open_call_outside_io_modules", "detail": name})
    return {
        "pass": len(findings) == 0,
        "finding_count": len(findings),
        "findings": findings,
        "policy": "No network imports, subprocess, dynamic execution, hidden telemetry, or host mutation helpers in the offline core. File IO is restricted to CLI/report/static audit modules."
    }

def write_audit(root: str, out: str):
    result = audit_path(root)
    with open(out, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    return result
