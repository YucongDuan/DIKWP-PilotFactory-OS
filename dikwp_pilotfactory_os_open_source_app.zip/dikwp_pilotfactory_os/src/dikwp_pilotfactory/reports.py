import csv, json, os
from typing import Dict, Any
from .dikwp import register_dikwp_for_use_case


def write_json(path: str, data: Any):
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def write_csv(path: str, rows, fieldnames):
    with open(path, 'w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader(); w.writerows(rows)


def render_sow(report: Dict[str, Any]) -> str:
    org = report.get("organization", "Unknown Organization")
    top = report.get("top_opportunities", [])
    lines = [
        f"# DIKWP Paid Pilot Statement of Work Draft",
        "",
        f"Client candidate: {org}",
        f"Portfolio route: {report.get('portfolio_route')}",
        "",
        "## Scope",
        "This draft scopes a human-reviewed DIKWP pilot. It does not grant official certification or production approval.",
        "",
        "## Recommended pilot candidates"
    ]
    for d in top:
        lines.append(f"- {d['use_case_id']}: {d['decision']} / tier={d['pricing_tier']} / modules={', '.join(d['recommended_modules'])}")
    lines += [
        "",
        "## Deliverables",
        "1. DIKWP pilot intake and evidence ledger.",
        "2. Use-case-specific TrustOS module routing.",
        "3. Risk, governance, and data readiness assessment.",
        "4. Official service trigger map.",
        "5. Pilot acceptance criteria and next-step commercial route.",
        "",
        "## Exclusions",
        "No legal certification, no production deployment, no live hardware control, no investment/medical/legal advice, and no official registry signature without separate authorized review."
    ]
    return "\n".join(lines)


def render_procurement_checklist(report: Dict[str, Any]) -> str:
    return "\n".join([
        "# Procurement Readiness Checklist",
        "",
        "- [ ] Organization sponsor identified.",
        "- [ ] Business pain and pilot KPI documented.",
        "- [ ] Data sources, retention, privacy, and cross-domain limits registered.",
        "- [ ] DIKWP module route reviewed by human owner.",
        "- [ ] Official DIKWP attribution and citation requirements included.",
        "- [ ] Certification, registry, or badge expectations separated from open-source demo claims.",
        "- [ ] Kill conditions and recovery plan drafted before deployment.",
        "- [ ] Paid service boundary and partner responsibilities confirmed."
    ])


def render_commercial_route(report: Dict[str, Any]) -> str:
    route = report.get("portfolio_route")
    if route == "sell_paid_pilot_first":
        action = "Lead with a 4-8 week paid pilot package and offer official DIKWP pilot report review."
    elif route == "sell_discovery_assessment_first":
        action = "Lead with a paid discovery assessment before proposing deployment."
    else:
        action = "Lead with free community materials, webinar, and TrustPassport registry invitation."
    return "\n".join([
        "# Commercial Route Brief",
        "",
        f"Recommended route: **{route}**",
        "",
        action,
        "",
        "## Monetization layers",
        "- Official pilot report review",
        "- Enterprise workshop",
        "- Industry adapter pack",
        "- TrustPassport registry / badge",
        "- Training certification",
        "- Partner onboarding",
        "- Production deployment support"
    ])


def write_outputs(out_dir: str, input_data: Dict[str, Any], report: Dict[str, Any]):
    os.makedirs(out_dir, exist_ok=True)
    write_json(os.path.join(out_dir, "pilot_opportunity_report.json"), report)
    rows = []
    for d in report["decisions"]:
        rows.append({
            "use_case_id": d["use_case_id"],
            "decision": d["decision"],
            "monetization_score": d["monetization_score"],
            "strategic_score": d["strategic_score"],
            "risk_score": d["risk_score"],
            "pricing_tier": d["pricing_tier"],
            "modules": ";".join(d["recommended_modules"]),
            "official_triggers": ";".join(d["official_triggers"])
        })
    write_csv(os.path.join(out_dir, "pilot_decision_matrix.csv"), rows, list(rows[0].keys()) if rows else ["use_case_id"])
    uc_by_id = {u["use_case_id"]: u for u in input_data.get("use_cases", [])}
    dikwp_ledger = [register_dikwp_for_use_case(uc_by_id.get(d["use_case_id"], {}), d) for d in report["decisions"]]
    write_json(os.path.join(out_dir, "dikwp_pilot_ledger.json"), dikwp_ledger)
    roi = {
        "assumption_boundary": "Prototype ROI assumptions only; not investment advice or guaranteed savings.",
        "assumptions": [
            {"metric": "pilot_duration_weeks", "default": 6},
            {"metric": "official_review_hours", "default": 12},
            {"metric": "enterprise_workshop_days", "default": 2},
            {"metric": "implementation_readiness", "source": "use case data readiness and integration complexity"}
        ]
    }
    write_json(os.path.join(out_dir, "roi_assumption_ledger.json"), roi)
    map_data = {
        d["use_case_id"]: {"modules": d["recommended_modules"], "official_triggers": d["official_triggers"]}
        for d in report["decisions"]
    }
    write_json(os.path.join(out_dir, "trustos_solution_map.json"), map_data)
    partner_route = {
        "organization": report.get("organization"),
        "route": report.get("portfolio_route"),
        "recommended_partner_status": "registered_partner_candidate" if report.get("average_monetization_score", 0) > 0.55 else "community_member_candidate",
        "human_review_required": True
    }
    write_json(os.path.join(out_dir, "partner_route_decision.json"), partner_route)
    with open(os.path.join(out_dir, "paid_pilot_statement_of_work.md"), 'w', encoding='utf-8') as f:
        f.write(render_sow(report))
    with open(os.path.join(out_dir, "procurement_checklist.md"), 'w', encoding='utf-8') as f:
        f.write(render_procurement_checklist(report))
    with open(os.path.join(out_dir, "commercial_route_brief.md"), 'w', encoding='utf-8') as f:
        f.write(render_commercial_route(report))
    with open(os.path.join(out_dir, "official_service_boundary.md"), 'w', encoding='utf-8') as f:
        f.write("# Official Service Boundary\n\nOpen-source reports are not official DIKWP certification. Official registry, badge, and signed reports require authorized human review.\n")
