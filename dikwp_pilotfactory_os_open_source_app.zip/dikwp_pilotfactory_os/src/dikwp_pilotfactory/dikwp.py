from typing import Dict, Any

def register_dikwp_for_use_case(uc: Dict[str, Any], score: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "C": uc.get("name", uc.get("use_case_id", "unknown")),
        "D": {
            "explicit_description": uc.get("description", ""),
            "industry": uc.get("industry", "unknown"),
            "current_evidence": uc.get("current_evidence", [])
        },
        "I": {
            "pain_level": uc.get("pain_level"),
            "budget_signal": uc.get("budget_signal"),
            "data_readiness": uc.get("data_readiness"),
            "regulatory_sensitivity": uc.get("regulatory_sensitivity"),
            "integration_complexity": uc.get("integration_complexity")
        },
        "K": {
            "recommended_modules": score.get("recommended_modules", []),
            "pilot_pattern": score.get("decision", "unknown")
        },
        "W": {
            "risk_score": score.get("risk_score"),
            "action_boundary": "pilot scoping and human-reviewed enterprise service only"
        },
        "P": {
            "target_benefit": uc.get("target_benefit", "unknown"),
            "time_window_months": uc.get("urgency_months", 6),
            "feedback": "pilot KPIs, customer acceptance, audit evidence, and official service conversion"
        },
        "R": {
            "monetization_score": score.get("monetization_score"),
            "strategic_score": score.get("strategic_score"),
            "residual": "scores are heuristic; official project viability requires human business development review"
        }
    }
