from typing import Dict, Any, List
from .text_utils import clamp

MODULE_KEYWORDS = {
    "ProofLedger": ["rag", "evidence", "citation", "report", "knowledge", "compliance"],
    "IntentGuard": ["agent", "tool", "permission", "prompt", "injection", "safety"],
    "AgentTrace": ["trace", "runtime", "incident", "replay", "workflow", "operation"],
    "MemoryLedger": ["memory", "context", "long term", "personalization", "privacy"],
    "SemanticEnergy": ["cost", "token", "energy", "finops", "waste", "budget"],
    "AnswerGraph": ["brand", "seo", "geo", "marketing", "answer", "citation"],
    "AICAP-Gateway": ["hardware", "device", "plc", "iot", "manufacturing", "robot", "drone", "gateway"],
    "TrustPassport": ["certification", "registry", "badge", "trust", "partner"],
    "IPGuardian": ["ip", "patent", "copyright", "trademark", "copycat"],
    "IntentEconomy": ["intent", "consent", "offer", "supplier", "marketplace"],
    "WorkFuture": ["job", "workforce", "reskill", "role", "replacement"],
    "ActiveHealth": ["health", "medical", "community", "prevention"],
    "SemanticJustice": ["law", "justice", "legal", "dispute"],
    "QuantLedger": ["quant", "trading", "backtest", "strategy", "program trading"]
}

OFFICIAL_TRIGGERS = {
    "certification": ["trust", "compliance", "procurement", "official", "registry", "audit"],
    "industry_adapter_pack": ["manufacturing", "energy", "finance", "medical", "transport", "hardware", "device"],
    "expert_workshop": ["innovation", "strategy", "triz", "executive", "roadmap"],
    "enterprise_deployment": ["integration", "production", "gateway", "agent", "workflow", "platform"],
    "legal_ip_review": ["ip", "patent", "copyright", "trademark", "copycat", "license"],
    "training_certification": ["training", "team", "education", "academy", "enablement"]
}

def infer_modules(uc: Dict[str, Any]) -> List[str]:
    text = " ".join([uc.get("name", ""), uc.get("description", ""), uc.get("industry", ""), uc.get("target_benefit", "")] + uc.get("risks", [])).lower()
    modules = set(uc.get("required_modules", []))
    for mod, kws in MODULE_KEYWORDS.items():
        if any(kw in text for kw in kws):
            modules.add(mod)
    if not modules:
        modules.update(["ProofLedger", "IntentGuard"])
    return sorted(modules)

def infer_official_triggers(uc: Dict[str, Any], modules: List[str]) -> List[str]:
    text = " ".join([uc.get("name", ""), uc.get("description", ""), uc.get("industry", ""), uc.get("target_benefit", "")] + modules).lower()
    triggers = []
    for trig, kws in OFFICIAL_TRIGGERS.items():
        if any(kw in text for kw in kws):
            triggers.append(trig)
    if "AICAP-Gateway" in modules:
        triggers.append("enterprise_deployment")
    if "TrustPassport" in modules:
        triggers.append("certification")
    return sorted(set(triggers))

def score_use_case(uc: Dict[str, Any], policy: Dict[str, Any]) -> Dict[str, Any]:
    pain = uc.get("pain_level", 3) / 5
    budget = uc.get("budget_signal", 3) / 5
    sponsor = 1.0 if uc.get("executive_sponsor") else 0.3
    data = uc.get("data_readiness", 3) / 5
    integration = uc.get("integration_complexity", 3) / 5
    regulatory = uc.get("regulatory_sensitivity", 3) / 5
    urgency = clamp((12 - min(uc.get("urgency_months", 6), 12)) / 12)
    evidence = clamp(len(uc.get("current_evidence", [])) / 4)
    risk_flags = len(uc.get("risks", []))
    risk = clamp(0.18 * regulatory + 0.25 * integration + 0.10 * risk_flags + (0.15 if "production" in uc.get("description", "").lower() else 0))
    monetization = clamp(0.24*pain + 0.20*budget + 0.16*sponsor + 0.14*urgency + 0.14*regulatory + 0.12*evidence)
    strategic = clamp(0.20*pain + 0.15*data + 0.15*regulatory + 0.15*evidence + 0.20*sponsor + 0.15*urgency)
    modules = infer_modules(uc)
    triggers = infer_official_triggers(uc, modules)
    if monetization >= 0.74 and risk <= 0.65:
        decision = "paid_pilot_candidate"
    elif monetization >= 0.55 and strategic >= 0.55:
        decision = "qualified_discovery_candidate"
    elif risk > 0.78:
        decision = "hold_for_risk_review"
    else:
        decision = "community_or_content_lead"
    if monetization >= 0.75:
        pricing = "enterprise_pilot"
    elif monetization >= 0.58:
        pricing = "starter_pilot"
    elif strategic >= 0.62:
        pricing = "workshop_or_assessment"
    else:
        pricing = "free_community_path"
    reasons = []
    if pain > 0.7: reasons.append("high stated pain")
    if budget > 0.6: reasons.append("visible budget signal")
    if sponsor > 0.9: reasons.append("executive sponsor present")
    if regulatory > 0.6: reasons.append("regulatory pressure creates buying urgency")
    if data < 0.4: reasons.append("data readiness is weak; start with assessment")
    if integration > 0.6: reasons.append("integration complexity requires official service or partner")
    if evidence < 0.3: reasons.append("evidence is weak; discovery report needed first")
    return {
        "use_case_id": uc.get("use_case_id"),
        "decision": decision,
        "monetization_score": round(monetization, 4),
        "strategic_score": round(strategic, 4),
        "risk_score": round(risk, 4),
        "recommended_modules": modules,
        "pricing_tier": pricing,
        "official_triggers": triggers,
        "reasons": reasons
    }

def analyze_portfolio(data: Dict[str, Any], policy: Dict[str, Any]) -> Dict[str, Any]:
    use_cases = data.get("use_cases", [])
    decisions = [score_use_case(uc, policy) for uc in use_cases]
    paid = [d for d in decisions if d["decision"] == "paid_pilot_candidate"]
    discovery = [d for d in decisions if d["decision"] == "qualified_discovery_candidate"]
    avg_monetization = round(sum(d["monetization_score"] for d in decisions)/max(1, len(decisions)), 4)
    avg_risk = round(sum(d["risk_score"] for d in decisions)/max(1, len(decisions)), 4)
    top = sorted(decisions, key=lambda d: (d["monetization_score"], d["strategic_score"]), reverse=True)[:3]
    if paid:
        route = "sell_paid_pilot_first"
    elif discovery:
        route = "sell_discovery_assessment_first"
    else:
        route = "community_content_and_registry_nurture"
    return {
        "system": "DIKWP PilotFactory OS",
        "version": "0.1.0",
        "organization": data.get("organization"),
        "sector": data.get("sector"),
        "region": data.get("region"),
        "use_case_count": len(use_cases),
        "average_monetization_score": avg_monetization,
        "average_risk_score": avg_risk,
        "portfolio_route": route,
        "decisions": decisions,
        "top_opportunities": top,
        "official_value_layer": [
            "official DIKWP pilot report review",
            "TrustPassport registry and signed badge",
            "industry adapter pack",
            "enterprise deployment support",
            "partner onboarding",
            "training certification"
        ]
    }
