def main():
    try:
        import streamlit as st
    except ImportError:
        raise SystemExit("Install with: pip install -e .[app]")
    st.title("DIKWP PilotFactory OS")
    st.write("Offline enterprise AI pilot conversion and DIKWP service routing demo.")
    st.info("Use the CLI for full report generation.")

if __name__ == "__main__":
    main()
