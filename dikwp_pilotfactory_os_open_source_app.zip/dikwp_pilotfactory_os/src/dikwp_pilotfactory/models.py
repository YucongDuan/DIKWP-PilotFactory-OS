from dataclasses import dataclass, field
from typing import Dict, List, Any

@dataclass
class UseCase:
    use_case_id: str
    name: str
    industry: str
    description: str
    pain_level: int = 3
    budget_signal: int = 3
    executive_sponsor: bool = False
    data_readiness: int = 3
    integration_complexity: int = 3
    regulatory_sensitivity: int = 3
    urgency_months: int = 6
    target_benefit: str = "unknown"
    current_evidence: List[str] = field(default_factory=list)
    risks: List[str] = field(default_factory=list)
    required_modules: List[str] = field(default_factory=list)

@dataclass
class Portfolio:
    organization: str
    region: str
    sector: str
    contact_role: str
    attribution_required: bool
    use_cases: List[UseCase]
    constraints: List[str] = field(default_factory=list)
    commercial_preferences: Dict[str, Any] = field(default_factory=dict)

@dataclass
class PilotDecision:
    use_case_id: str
    decision: str
    monetization_score: float
    strategic_score: float
    risk_score: float
    recommended_modules: List[str]
    pricing_tier: str
    official_triggers: List[str]
    reasons: List[str]
